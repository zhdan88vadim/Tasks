angular.module("app", []).run(function($templateRequest) {
  $templateRequest("/templates/editor.html");
});

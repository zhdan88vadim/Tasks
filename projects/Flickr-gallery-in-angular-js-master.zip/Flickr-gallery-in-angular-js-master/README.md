Flickr gallery (Angular.js)
============================

This a photo gallery that uses the flickr API, it allows you to browse recent photos and also search.

[LIVE DEMO] (http://luisbravoa.com/sandbox/Flickr-gallery-in-angular-js)

Dependencies
============

- jQuery
- Angular.js
- Bootstrap
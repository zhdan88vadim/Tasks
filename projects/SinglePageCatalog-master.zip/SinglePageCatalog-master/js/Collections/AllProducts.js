App.Collections.AllProducts = {
    collection: [],
    fetch: function() {
        var that = this;
        $.get('http://78.47.183.51:8011/api/products', function(resp) {
            $.each(resp, function() {
                that.collection.push(
                    new App.Models.Product(this.Name, this.Price, this.Image)
                );
            });

            $(App.Collections.AllProducts).trigger('model:updated');
        });
    }
};
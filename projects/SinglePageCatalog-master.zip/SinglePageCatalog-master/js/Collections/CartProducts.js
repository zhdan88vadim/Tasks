App.Collections.CartProducts = {
    collection: []
};
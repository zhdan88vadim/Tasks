App.Views.ProductCart = function () {
    var that = $.extend({}, App.Views.BaseView);

    that.template =  $('#TemplateProductCart');
    that.el = $('#content');
    that.events = {
        '.remove': {
            ev:'click',
            action: 'removeFromCart'
        }
    };
    that.removeFromCart = function() {
        this.model.removeFromCart();
    };
    return that;
};

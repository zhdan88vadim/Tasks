App.Views.BaseCollectionView = {
    model: undefined,
    view: null,
    viewsList: [],
    wrapperClass: undefined, //if you want to wrap all collection in div - set a class for this div
    renderAfter: undefined, //function to call after collection render
    collection: undefined,
    renderCollection: function (collection) {
        var that = this,
            elem_to_append;

        this.model = collection;

        this.collection = collection;

        this.el.html('');
        if(this.wrapperClass) {
            elem_to_append = $('<div class="'+ this.wrapperClass +'"></div>');
            this.el.append(elem_to_append);
        } else {
            elem_to_append = this.el;
        }
        $.each(collection.collection, function () {
            var elem = $('<div></div>'),
                view = new that.view();

            elem_to_append.append(elem);
            view.render(this, elem);
        });

        if(typeof this.renderAfter === 'function') {
            this.renderAfter();
        }
    }
};
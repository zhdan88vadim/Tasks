App.Views.BaseView = {
    events: {

    },
    render: function (model, elem_to_render) {
        var elems_to_insert_model_val,
            model_val_name,
            that = this,
            el;
        if (typeof model === 'object') {
            this.model = model;
        }

        if (!elem_to_render) {
            elem_to_render = this.el;
        }

        //rendering our template
        elem_to_render.html(this.template.html());
        //looking for models

        $.each(this.events, function(selector, ev_obj) {
            //use $.proxy to set this - as view object
            elem_to_render.find(selector).on(ev_obj.ev, $.proxy(that[ev_obj.action], that));
        });

        //Super simply template engine. I understand that to be flexible
        //it have to be base on RegExp
        if (this.model) {
            elems_to_insert_model_val = elem_to_render.find('[data-text]');
            $.each(elems_to_insert_model_val, function () {
                el = $(this);
                model_val_name = el.data('text');
                if (that.model[model_val_name] !== undefined) {
                    el.text(that.model[model_val_name]);
                }
            });

            elems_to_insert_model_val = elem_to_render.find('[data-bg-img]');
            $.each(elems_to_insert_model_val, function () {
                el = $(this);
                model_val_name = el.data('bg-img');
                if (that.model[model_val_name] !== undefined) {
                    el.css({backgroundImage: 'url(' + that.model[model_val_name] +')'})
                }
            });
        }
    }
};
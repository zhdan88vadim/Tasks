App.Views.ProductMain = function () {
    var that = $.extend({}, App.Views.BaseView);

    that.template =  $('#TemplateProductMain');
    that.el = $('#content');
    that.events = {
        '.add': {
            ev:'click',
            action: 'addToCart'
        }
    };
    that.addToCart = function() {
        this.model.addToCart(
            function() {
                App.Router.setHash('cart');
            }
        );
    };
    return that;
};

App.Views.CartProductsCollection = function () {
    var that = $.extend({}, App.Views.BaseCollectionView);

    that.view = App.Views.ProductCart;
    that.el = $('#content');
    that.wrapperClass = 'CartProducts';


    return that;
};

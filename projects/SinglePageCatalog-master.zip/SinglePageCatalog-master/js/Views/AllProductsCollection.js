App.Views.AllProductsCollection = function () {
    $.extend(this, App.Views.BaseCollectionView);

    this.view = App.Views.ProductMain;
    this.el = $('#content');
    this.wrapperClass = 'AllProducts';
    this.renderAfter = function () {
        var that = this;
        console.log('adding scroll listener for window');
        $(window).on('scroll', function () {
            if ($(window).scrollTop() == $(document).height() - $(window).height()) {
                that.collection.fetch();
            }
        });
    };
    this.viewDestroy = function () {
        console.log('deleting scroll listener for window');
        $(window).off('scroll');
    };
};

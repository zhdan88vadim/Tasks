App.Models.Product = function (Name, Price, Image) {
    this.Name = Name;
    this.Price = Price;
    this.Image = Image;
};

App.Models.Product.prototype.addToCart = function (callback) {
    var that = this;
    $.post('http://78.47.183.51:8011/api/products/addtocart', function (resp) {
        App.Collections.CartProducts.collection.push(that);
        if(callback) {
            callback();
        }
    });
};

App.Models.Product.prototype.removeFromCart = function () {
    var product_position = App.Collections.CartProducts.collection.indexOf(this);
    App.Collections.CartProducts.collection.splice(product_position, 1);
    $(App.Collections.CartProducts).trigger('model:updated'); //maybe better to have this logic in App.Collections.CartProducts ?
};
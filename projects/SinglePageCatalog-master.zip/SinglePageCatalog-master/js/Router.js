App.Router = {
    currentView: undefined,
    routes: {
        '': function () {
            var view = new App.Views.AllProductsCollection();
            App.Router.currentView = view;
            view.renderCollection(App.Collections.AllProducts);
        },
        'cart': function () {
            var view = new App.Views.CartProductsCollection();
            App.Router.currentView = view;
            view.renderCollection(App.Collections.CartProducts);
        }
    },
    start: function () {
        var that = this;
        this.callCurrentRouteAction();

        $(window).on('hashchange', function (a, b, c) {
            that.callCurrentRouteAction();
        });
    },
    getHash: function () {
        var match = (window || this).location.href.match(/#(.*)$/);
        return match ? match[1] : '';
    },
    callRouteAction: function (hash) {
        if (this.routes[hash]) {
            this.routes[hash]();
        }
    },
    callCurrentRouteAction: function () {
        var that = this;

        if(this.currentView) {
            if(this.currentView.viewDestroy) {
                this.currentView.viewDestroy();
            }
            $(this.currentView.model).off('model:updated');
        }

        this.callRouteAction(this.getHash());

        //redrawing page on current view's model refresh
        $(this.currentView.model).on('model:updated', function(){
            that.callCurrentRouteAction();
        });
    },
    setHash: function(hash) {
        window.location.hash = hash;
    }
};
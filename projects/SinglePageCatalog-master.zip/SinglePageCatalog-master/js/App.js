var App = (function () {
    function OnInitActions() {
        App.Collections.AllProducts.fetch();
    }


    $(function () {
        OnInitActions();
        App.Router.start();
    });


    return {
        Views: {},
        Models: {},
        Collections: {}
    }
}());

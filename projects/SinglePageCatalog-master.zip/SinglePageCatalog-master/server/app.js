var express = require('express'),
    app = express(),
    server = require('http').createServer(app),
    path = require('path');


app.use(express.static(path.join(__dirname, "site")));
app.use(express.methodOverride());
app.use(express.bodyParser()); // стандартный модуль, для парсинга JSON в запросах
app.use(function(req, res, next) {
    console.log(132123)
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    next();
});
app.use(app.router)

app.use(function (req, res, next) {
    res.status(404);
    res.send({ error: 'Not found' });
});


app.get('/api/products', function(req, res) {
    var products = [],
        rand;
    for(var i = 0; i < 10; i++) {
        rand = Math.ceil(Math.random()*10);
        products.push({
            Name: 'Name'+Math.random().toFixed(2),
            Price: (Math.random() * 10).toFixed(2),
            Image: 'img/' + rand + '.jpg'
        });
    }

    res.send(products);
});

app.post('/api/products/addtocart', function(req, res) {
    res.send({});
});



server.listen(8011);
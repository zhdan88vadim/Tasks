SinglePageCatalog
=================

Implemented simple single page catalog+cart. No SPA frameworks used

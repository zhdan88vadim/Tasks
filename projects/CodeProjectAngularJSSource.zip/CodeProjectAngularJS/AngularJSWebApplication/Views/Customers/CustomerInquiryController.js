﻿"use strict";

define(['application-configuration', 'customersController'], function () {

});

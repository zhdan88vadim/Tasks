Managing users authentication and route access in angularjs
==============

Watch the tutorial on youtube
--------------

[![Video tutorial](http://img.youtube.com/vi/3H_YqMITSi0/0.jpg)](https://www.youtube.com/watch?v=3H_YqMITSi0)
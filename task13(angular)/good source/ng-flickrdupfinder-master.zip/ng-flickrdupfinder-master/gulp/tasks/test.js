var gulp = require('gulp');

gulp.task('test', ['build']);

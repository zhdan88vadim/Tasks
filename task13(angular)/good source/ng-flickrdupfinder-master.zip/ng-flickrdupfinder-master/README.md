
# ng-flickrdupfinder

[![travis badge][travis-badge]][travis-url]
[![node versioneye badge][node-badge]][node-url]
[![bower versioneye badge][bower-badge]][bower-url]
[![Gitter][gitter-badge]][gitter-url]

next-generation / angularjs flickr duplicate finder

easily find and tag duplicate images in your flickr account. currently
uses filename and date_taken timestamp to identify duplicates, simple
but often quiet effective. inspired by the now discontinued
[flickrdupfinder] project.

access live version (beta): [http://ng-flickrdupfinder.lefant.net/#/]

--

oauth authenticated access to flickr is proxied via my own instance of
oauthd running on heroku:
https://github.com/lefant/oauthd-lefant-heroku


[travis-badge]: https://travis-ci.org/lefant/ng-flickrdupfinder.svg
[travis-url]: https://travis-ci.org/lefant/ng-flickrdupfinder
[node-badge]: https://www.versioneye.com/user/projects/54f1a2294f3108959a00059c/badge.svg?style=flat
[node-url]: https://www.versioneye.com/user/projects/54f1a2294f3108959a00059c#dialog_dependency_badge
[bower-badge]: https://www.versioneye.com/user/projects/54f1a2f44f31083e1b000563/badge.svg?style=flat
[bower-url]: https://www.versioneye.com/user/projects/54f1a2f44f31083e1b000563#dialog_dependency_badge
[gitter-badge]: https://badges.gitter.im/Join%20Chat.svg
[gitter-url]: https://gitter.im/lefant/ng-flickrdupfinder
[flickrdupfinder]: https://github.com/christophemaillot/flickrdupfinder
[http://ng-flickrdupfinder.lefant.net/]: http://ng-flickrdupfinder.lefant.net/?utm_source=github.com&utm_medium=social&utm_campaign=readme#/

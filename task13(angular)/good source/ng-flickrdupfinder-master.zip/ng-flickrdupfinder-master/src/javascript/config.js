'use strict';

module.exports = angular.module('flickrDupFinderConfig', [])
  .constant('OAUTHD_URL', 'https://oauthd-lefant.herokuapp.com')
  .constant('APP_PUBLIC_KEY', '4UET5aV8f_Np4Eam-BCfQ8zvNzI') //oauthd-lefant
  //.constant('OAUTHD_URL', 'http://oauth.io')
  //.constant('APP_PUBLIC_KEY', 'cF4gOblEUpueTtsL44-gVjZeeXM') //oauth.io
